import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import DAO.StudentDao;
import model.Student;

class StudentDaoTest {
    private StudentDao studentDao;

    @BeforeEach
    public void setUp() throws Exception {
        studentDao = new StudentDao();
    }

    @AfterEach
    public void tearDown() throws Exception {
        
        studentDao.closeConnection();
    }

    @Test
    public void testInsertStudent() {
       
        String name = "John Doe";
        int age = 20;
        studentDao.insertstudent(name, age);
        
        
        List<Student> students = studentDao.getAllStudents();
        
      
        assertTrue(students.stream().anyMatch(s -> s.getName().equals(name) && s.getAge() == age));
    }

    @Test
    public void testGetAllStudents() {
        
        List<Student> students = studentDao.getAllStudents();
        
       
        assertNotNull(students);
        assertFalse(students.isEmpty());
    }

    @Test
    public void testUpdateStudent() {
        
        List<Student> students = studentDao.getAllStudents();
        
        Student student = students.get(0);
        
        String newName = "Jane Smith";
        
        int newAge = 25;
        studentDao.updateStudent(student.getId(), newName, newAge);
        
        Student updatedStudent = studentDao.getAllStudents().stream()
                .filter(s -> s.getId() == student.getId())
                .findFirst()
                .orElse(null);
        
      
        assertNotNull(updatedStudent);
        
        assertEquals(newName, updatedStudent.getName());
        
        assertEquals(newAge, updatedStudent.getAge());
    }

    @Test
    public void testDeleteStudent() {
     
        List<Student> students = studentDao.getAllStudents();
        
        Student student = students.get(0);
        
       
        studentDao.deleteStudent(student.getId());
        
       
        List<Student> updatedStudents = studentDao.getAllStudents();
        assertFalse(updatedStudents.contains(student));
    }
}
