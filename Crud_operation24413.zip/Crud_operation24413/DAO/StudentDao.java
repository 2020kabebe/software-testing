package DAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;

import model.Student;

import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
public class StudentDao {
	
		 private static final String URL = "jdbc:mysql://localhost:3306/testcases";
		 private static final String USERNAME = "root";
		 private static final String PASSWORD = "Amahoro@1";
		 private Connection connection;
		 
		 public StudentDao() {
			 try {
				 connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			 } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		 }
		 public void insertstudent(String name, int age) {
		        String query = "INSERT INTO student (name, age) VALUES (?, ?)";
		        try (PreparedStatement statement = connection.prepareStatement(query)) {
		            statement.setString(1, name);
		            statement.setInt(2, age);
		            statement.executeUpdate();
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		    }
		 public void updateStudent(int id, String name, int age) {
		        String query = "UPDATE student SET name = ?, age = ? WHERE id = ?";
		        try (PreparedStatement statement = connection.prepareStatement(query)) {
		            statement.setString(1, name);
		            statement.setInt(2, age);
		            statement.setInt(3, id);
		            statement.executeUpdate();
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		    }
		 public void deleteStudent(int id) {
		        String query = "DELETE FROM student WHERE id = ?";
		        try (PreparedStatement statement = connection.prepareStatement(query)) {
		            statement.setInt(1, id);
		            statement.executeUpdate();
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		    }
		 
	public List<Student> getAllStudents() {
	    List<Student> students = new ArrayList<>();
	    String query = "SELECT * FROM student";
	    try (PreparedStatement statement = connection.prepareStatement(query);
	         ResultSet resultSet = statement.executeQuery()) {
	        while (resultSet.next()) {
	            int id = resultSet.getInt("id");
	            String name = resultSet.getString("name");
	            int age = resultSet.getInt("age");
	            students.add(new Student(id, name, age));
	        }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return students;
	}
	public void closeConnection() {
		try {
		  if (connection != null) {
            connection.close();
            System.out.println("Connection closed successfully");
         }
		}catch (SQLException ex){
            ex.printStackTrace();
        }
		
	}
	  


}
