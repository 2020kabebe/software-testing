import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import DAO.CourseDao;
import model.Course;

class CourseDaoTest {
    private CourseDao courseDao;

    @BeforeEach
    public void setUp() throws Exception {
        courseDao = new CourseDao();
    }

    @AfterEach
    public void tearDown() throws Exception {
        // Close the database connection after each test case
        courseDao.closeConnection();
    }

    @Test
    public void testInsertCourse() {
        // Create a new course and insert it into the database
        Course course = new Course(0, "SOFTWARE TESTING", "Test Description");
        courseDao.insertCourse(course);
        System.out.println("Course inserted: " + course);
       
        
        // Retrieve the course from the database and assert that it exists
        List<Course> courses = courseDao.getAllCourses();
        assertTrue(courses.contains(course));
    }

    @Test
    public void testGetAllCourses() {
        // Get all courses from the database
        List<Course> courses = courseDao.getAllCourses();
        
        // Assert that the list is not null and not empty
        assertNotNull(courses);
        assertFalse(courses.isEmpty());
    }

    @Test
    public void testUpdateCourse() {
        // Get the first course from the database
        List<Course> courses = courseDao.getAllCourses();
        Course course = courses.get(0);
        
        // Update the course name
        String newName = "Updated Course Name";
        course.setName(newName);
        courseDao.updateCourse(course);
        
        // Retrieve the updated course from the database
        Course updatedCourse = courseDao.getAllCourses().stream()
                .filter(c -> c.getId() == course.getId())
                .findFirst()
                .orElse(null);
        
        // Assert that the course name has been updated
        assertNotNull(updatedCourse);
        assertEquals(newName, updatedCourse.getName());
    }

    @Test
    public void testDeleteCourse() {
        // Get the first course from the database
        List<Course> courses = courseDao.getAllCourses();
        Course course = courses.get(0);
        
        // Delete the course from the database
        courseDao.deleteCourse(course.getId());
        
        // Assert that the course no longer exists in the database
        List<Course> updatedCourses = courseDao.getAllCourses();
        assertFalse(updatedCourses.contains(course));
    }
}
