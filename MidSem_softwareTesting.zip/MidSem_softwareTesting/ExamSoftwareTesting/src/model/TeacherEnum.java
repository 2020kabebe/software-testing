package model;

public enum TeacherEnum {
	MASTERS,
	PHD,
	PROFESSOR

}
